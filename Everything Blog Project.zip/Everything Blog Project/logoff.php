<!-- 
Project Name: CST-126 Project
Programmer:   Ray Omoregie
Date:         May 16, 2019
Description: Add user logoff page . 
 -->


<?php
include 'functions.php';
saveUserId(0);
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<link rel="stylesheet" href="css/style.css">

<title>User Logoff Page</title>
</head>
<body>
	<h2 id="banner"> WELCOME to "The Everything Blog Page. This is the Logoff screen"</h2>
	<hr>
	<!-- TODO: properly center the menu so that there is not such a huge gap between items -->

	<br>
	<br>
	<form action="loginController.php" method="post">
		<table>
			<tr>
				<td>Username:</td>
				<td><input type="text" name="Username"></td>
			</tr>
			<tr>
				<td>Password:</td>
				<td><input type="password" name="Password"></td>
			</tr>
		</table>
		<input type="submit" value="Login">
	</form>
	<a href="index.html">Home</a>
</body>
</html>

Congratulations. You have just logged off!
</body>
</html>