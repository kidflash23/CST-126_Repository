<!-- 
Project Name: CST-126 Project 
Programmer:   Ray Omoregie
Date:         May 16, 2019
Description:     This page is the main page of the user application where they can acess other parts of the blog. 
 -->
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<link rel="stylesheet" href="css/style.css">
>
<title>User Login Page</title>
</head>
<body>
	<h2 id="banner"> WELCOME to "The Everything Blog"</h2>
	<hr>
	<!-- TODO: properly center the menu so that there is not such a huge gap between items -->
	<div class="menu">
		<div class="menu-item">
			<a href="login.html">Login</a>
		</div>
		<div class="menu-item">
			<a href="registerUser.html">Register</a>
	
		</div>
		<div class="menu-item">
			<a href="index.html">Home</a>
		</div>
		<div class="menu-item">
			<a href="logoff.php">Log out</a>
		</div>
	</div>
	<br>
	<br>
	<form action="loginController.php" method="post">
		<table>
			<tr>
				<td>Username:</td>
				<td><input type="text" name="Username"></td>
			</tr>
			<tr>
				<td>Password:</td>
				<td><input type="password" name="Password"></td>
			</tr>
		</table>
		<input type="submit" value="Login">
	</form>
	<a href="index.html">Home</a>
</body>
</html>
<?php
require 'functions.php';

// user-input variables:
$username = trim($_POST["Username"]);
$password = trim($_POST["Password"]);

if ($username == NULL || $username == '' || $password == NULL || $password == '') {
    echo "Username and Password are required fields and cannot be blank.<br>";
} else {
    // connection to the DB
    $SQLConnect = dbConnect();
    
    // Query string
    $Query = "SELECT * FROM users WHERE USERNAME = '$username' AND PASSWORD = '$password';";
    
    $result = $SQLConnect->query($Query);
    
    // check results
    if ($result->num_rows == 0) {
        echo "Login failed. Invalid Username or Password";
    } else if ($result->num_rows == 1) {
        // associated array to fetch first and last name.
        $resultArray = $result->fetch_assoc();
        // added the following function to save the login to the session
        saveUserId($resultArray["USER_ID"]);
        
        echo "Login successful. Welcome " . $resultArray["FIRST_NAME"] . " " . $resultArray["LAST_NAME"];
    } else if ($result->num_rows > 1) {
        echo "Multiple user under that username/password";
    } else {
        echo $dbConnect->error;
    }
}
$dbConnect->close();
?>
</body>
</html>