<!-- 
Project Name: CST-126 Project v7
Programmer:   Ray Omoregie
Date:         April 7, 2019
Synopsis:     Add the ability to leave a comment on a blog post.
 -->

<?php
function dbConnect() {
    $host="localhost";
    $username="root";
    $password="root";
    $database="everything_blog";
    
  $mysql1 = new $mysql1 ($host, $username, $password, $database);
        // check for connection errors
        if ($mysql1->connect_error) {
            echo "Could not connect to the DB " . $mysql1->connect_error;
        } else {
            //return the object if no errors.
            return $mysql1;
        }
    }

//save the userid into the session
function saveUserId($id) {
    session_start();
    $_SESSION[USER_ID]=$id;
}

//return the USER_ID variable from the session
function getUserId()
{
    session_start();
    return $_SESSION["USER_ID"];
}




function getComments($id) {
    $query="SELECT comments.TEXT
            FROM comments
            WHERE comments.DELETED != '1' AND comments.PARENT_ID = '$id';";
    
    $mysql1=dbConnect();
    
    $result=$mysql1->query($query);
    
    $mysql1->close();
    
    return $result;
}



//Deletes a blog post 
function deleteBlog($id) {
    $query="UPDATE blogs SET DELETED = 1 WHERE ID = $id";
    
    $mysql1=dbConnect();
    
    if($mysql1->query($query)) {
        return "Congrats. The blog post has been removed!";
    } else {
        return "Blog could not be removed. ".$mysql1->error;
    }
    
    $mysql1->close();
}

//Deletes a user.
function deleteUser($id) {
    $thisID = getUserID();
    
    if(thisID!=$id) {
        $mysql1 = dbConnect();
        
        $query = "DELETE FROM users WHERE $id";
        
        if($mysql1->query($query)) {
            echo "User ID $id deleted!";
       
    }
    $mysql1->close();
}



//How to update role for user
function updateRole ($id, $newRole) {
    $mysql1 = dbConnect();
    
    $thisUser=getUserInfo(getUserId());
    
    if($thisUser["ID"] == $id || $thisUser["ID"] < 1 || $thisUser["ROLE"] != "admin") {
        if ($thisUser["ID"] == $id) {
            echo "Cannot modify self!";
        } else if ($thisUser["ID"] < 1) {
            echo "Must be logged in!";
        } else {
            echo "Must be an admin to execute this function!";
        }
    } else {
        $query = "UPDATE users SET ROLE='$newRole' WHERE USER_ID='$id'";
        
        if($mysql1->query($query)) {
            echo "User ID $id priveleges modified to $newRole!";
        } else {
            echo "Could not modify the role! ".$mysql1->error;
        }
    }
    $mysql1->close();
}

}
?>